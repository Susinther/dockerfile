package com.levo.dockerexample;

public class PlaceHolderForTest {

}
