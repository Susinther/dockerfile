package com.levo.dockerexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerApp {
	public static void main(String[] args) {
		SpringApplication.run(DockerApp.class, args);
	}
}
